#include <stdlib.h>
#include <stdio.h>
#include<fcntl.h>

int main(int argc,char *argv[])
{
	char buffer[256];
	if (argc==1){printf("no command line arguement given\n");}
	if(argc==3){
			printf("%s\n",argv[1]);	
			int fd=open(argv[1],O_RDONLY,0777);
			int fd2=open(argv[2],O_CREAT | O_RDWR,0777 );
			if(fd==-1 || fd2==-1){printf("ERROR OPENING ANY OF THE FILE\n"); exit(1);}
			while(1){	
				int n=read(fd,buffer,255);
				if(n<=0)
				{break;}
				write(fd2,buffer,n);
				}
				unlink(argv[1]);
	
			}printf("moved\n");
}
