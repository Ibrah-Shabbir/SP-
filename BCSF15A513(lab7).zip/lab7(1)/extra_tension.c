#include <stdlib.h>
#include <stdio.h>
#include<fcntl.h>

int main(int argc,char *argv[])
{
		char buffer[256];
	if(argc != 1){
		close(1);

			int fd=open("file_extra.c",O_RDONLY,0777);
			close(1);
			int fd2=open(argv[1],O_CREAT | O_RDWR,0777);
		
			while(1){
				printf("hell1\n");
				printf("hell2\n");
				printf("hell3\n");	
				int n=read(fd,buffer,255);
				if(n<=0)
				{break;}
				write(fd2,buffer,n);
				}
		
	}

	if(argc == 1){
			int fd=open("file_extra.c",O_RDONLY,0777);
		
			while(1){
				printf("hell1\n");
				printf("hell2\n");
				printf("hell3\n");	
				int n=read(fd,buffer,255);
				if(n<=0)
				{break;}
				write(1,buffer,n);
				}
		
	}

	printf("Welcome\n");

	return 0;
}
