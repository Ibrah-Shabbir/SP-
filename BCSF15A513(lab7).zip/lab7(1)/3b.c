#include <stdlib.h>
#include <stdio.h>
#include<fcntl.h>

int main()
{
	char buffer[256];
	int fd=open("f.txt",O_RDONLY);
	int fd2=open("newfile.txt",O_CREAT | O_RDWR ,0777);
	if(fd==-1 || fd2==-1){printf("ERROR OPENING ANY OF THE FILE\n"); exit(1);}
	while(1){	
		int n=read(fd,buffer,255);
	
		if(n<=0)
			{break;}
	
		write(fd2,buffer,n);
		
		}

	
	

}
