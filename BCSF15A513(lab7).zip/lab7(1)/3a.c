#include <stdlib.h>
#include <stdio.h>
#include<fcntl.h>

int main()
{
	char buffer[256];
	int fd=open("file.txt",O_CREAT | O_RDWR,0777 );
	if(fd==-1){printf("ERROR OPENING ANY OF THE FILE\n");exit(1);}
	else{
	int n=read(0,buffer,255);
	write(fd,buffer,n);}
	

}
