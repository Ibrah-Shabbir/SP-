#include <stdlib.h>
#include <stdio.h>
#include<fcntl.h>

int main()
{

printf("hell1");
int x=1+2;
printf("hell2");
int y=3+2;
printf("hell3");

printf("hell4");
int z=4+2;
printf("hell5");
int z=5+2;
printf("hell6");

}
