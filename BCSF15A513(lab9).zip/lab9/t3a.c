#include<fcntl.h>
#include<stdio.h>

int main()
{
 

	int buff[256];
	//close(1);
	int f0=open("f1.txt",O_RDONLY);
	if(f0<=-1)
	{
		perror("ERROR OCCUR OPENING THE FILE");
		
	}
	int f2=dup2(1,2);
	int f1=open("f1.txt",O_RDONLY|O_WRONLY);
	while(1)
	{
		int n=read("f1.txt",buff,255);
		if(n<=0)
		{
			break;
		} 
		write(f1,buff,n);
	} 
}
