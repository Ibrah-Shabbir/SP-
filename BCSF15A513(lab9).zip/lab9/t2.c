#include<fcntl.h>
#include<stdio.h>

int main()
{

char buffer[256];
close(1);
int fd1=open("t1file.txt",O_RDONLY);
if(fd1==-1)
{

	int fd2=open("errorAndOutput.txt",O_CREAT|O_RDWR,0777);
	int fd_new = dup(fd2);
	//printf("%d,%d,%d\n",fd2,fd_new,fd1);
	perror("ERROR WHILE OPENING THE FILE");
	while(1){	
				int n=read(fd_new,buffer,255);
				if(n<=0)
				{break;}
				write(fd2,buffer,n);
				
		}
}
else
{
printf("hello wrong\n");

	int fd2=open("errorAndOutput.txt",O_CREAT|O_RDWR,0777);
	int fd_new = dup(fd1);
	//printf("%d,%d,%d\n",fd2,fd_new,fd1);
	//perror("FILE EXISTS");
	while(1){	
				int n=read(fd_new,buffer,255);
				if(n<=0)
				{break;}
				write(fd2,buffer,n);
				
		}
}
return 0;
}
