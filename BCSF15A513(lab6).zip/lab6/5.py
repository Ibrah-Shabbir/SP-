string=raw_input("enter the data : ")
string =string.upper()
print string
