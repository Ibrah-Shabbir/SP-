import calendar

month=calendar.month(2018,5)
print month
