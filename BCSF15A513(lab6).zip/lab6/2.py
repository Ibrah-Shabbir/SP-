data= raw_input("enter the number= ")
rangee=int(data)
dict={}
#print rangee

count=0

while count<rangee:
	count+=1
	#print count
	dict[count]=count*count


print dict
	
	





	
	
	

