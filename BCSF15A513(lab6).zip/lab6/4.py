string=raw_input("Enter values : ")
print string
l=[]
l=string.split(",")
l.sort()
l2=[]
store=""
for index,val in enumerate(l):
	if not val in l2:
		if index!=0:
			store+=","
		l2.append(val)
		store+=val
		
print store
