string=raw_input("Enter values : ")
print string

string.split(',')

listt=[]

listt.append(string)


print listt


	
	
	

