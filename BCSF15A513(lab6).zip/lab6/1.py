n=range(2000,3201)
list=[]
for val in n :
	if val%7==0 and val%5!=0:
		list.append(val)

print list




 
