string=raw_input("enter data = ")
l=[]

l=string.split(" ")
l.sort()
l2=[]
store=""
for val in l:
	if not val in l2:
		l2.append(val)
		store+=val
		store+=" "


print store
