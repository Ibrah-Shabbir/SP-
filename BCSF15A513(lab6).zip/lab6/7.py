string = raw_input("enter the data : ")
count_alpha=0
count_digit=0

for ch in string:
	#print ch
	if ch.isdigit():
		count_digit+=1
	elif ch.isalpha():
		count_alpha+=1


print "alphabets count = ",count_alpha
print "digits count = ",count_digit



