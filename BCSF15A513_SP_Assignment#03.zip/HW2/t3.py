from array import *


if __name__=="__main__":
	counter=0
	arr=array('i',[])
	arr2=[[0 for y in xrange(8)]for x in xrange(8)]	

	print "hello"
	
	for i in range(8):
	   for j in range(8):
		#print i
		#arr.append(i)
		#arr2.append(i+j)
		#print arr[i]
		arr2[i][j]=counter
		counter+=1		
		#print arr2[i][j]," "
	print arr2
	
	input_arr=[[0 for y in xrange(2)]for x in xrange(2)]
	for i in range(2):
	   for j in range(2):
		input_arr[i][j]=raw_input("Enter the value : ").strip(' ,')
		
	
	flag=False
	save=input_arr[0][0]
	#print save	
	for i in range(8):
	   for j in range(8):
		#if arr2[1][0]== input_arr[0][0]:
		if arr2[i][j]==int(save):
			#print "FOUND ONE"
			if arr2[i][j+1]==int(input_arr[0][1]) and j+1<8:
				if arr2[i+1][j]==int(input_arr[1][0]) and i+1<8:
					if arr2[i+1][j+1]==int(input_arr[1][1]):
							print "The given matrix found"
							flag=True
							print input_arr
							break;
		
		elif j==7 and i==7 and flag==False:
			print "NOT FOUND"
			break;
		
	
