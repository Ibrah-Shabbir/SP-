import requests
from bs4 import BeautifulSoup
import os


def get_parent_links(URL,keyword):
	list_=[]
	count=0
	req = requests.get(URL,stream =True)
 	if req.status_code == 200:
 		parser_obj = BeautifulSoup(req.content, "html.parser")
 		a_tag_list = parser_obj.find_all("a",rel="bookmark")
 		#print li_tag
 		for a_tag in a_tag_list:
			#print a_tag
 			#sports_link = a_tag['href']
			if keyword in a_tag.get_text() and count<6:
				count+=1
				print "YESSSS"
				list_.append(a_tag["href"])
 		
	return list_	

###############################################
def initialize(keyword):
	URL = "https://propakistani.pk/category/sports/"
	p_links = get_parent_links(URL,keyword)
 	print p_links

################################################
def get_input():
	print "********WELCOME TO PROPAKISTANI.pk*********"
 	inputt = raw_input("Enter the keyword you want to search : ")
 	return inputt
################################################

if __name__ == "__main__":
 	keyword=get_input()
	initialize(keyword)
