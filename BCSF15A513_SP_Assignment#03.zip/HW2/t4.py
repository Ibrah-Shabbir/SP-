import psutil
import os
import datetime
import sys


#print "" os.getpid()

if __name__=="__main__":
  if len(sys.argv)==3:
	f=open('file.txt','w')
	proc=int(sys.argv[2])
	print "helloo\n", proc
	p=psutil.Process(proc)
	print "Process ID : ", p.pid
	print  "Process Status : ", p.status
	gp=psutil.Process(p.ppid)
	print  "Process Parent ID : ", p.ppid
	print  "Process Parent Name : ", gp.name
	print "Process Creation Time : ",format(datetime.datetime.fromtimestamp(p.create_time))
	print "Process Open Files : \n ", p.get_open_files
	#for i in arr
	#	print i
	print "Meamory Info: \n", p.get_memory_info()
	
   else:
	print "There should be only one arguement i.e; Process ID \n"
	
	
	#print gp.name
	
#print p.CreationTime
