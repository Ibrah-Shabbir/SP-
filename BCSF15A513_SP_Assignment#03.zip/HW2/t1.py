import requests
import os
from PIL import Image
from bs4 import BeautifulSoup
from StringIO import StringIO
#import fnmatch
from selenium import webdriver
import datetime 
from selenium.webdriver.common.keys import Keys
#from urllib import request


def get_qaris(URL):
	if(URL):
		list_=[]
		#pre_tag_list=[]
		#print "YES"
		req = requests.get(URL)
		if req.status_code == 200:
			#print "YES"
			parser_obj = BeautifulSoup(req.content, "html.parser")
			#pre_tag_list = parser_obj.find_all("pre")
			a_tag_list=parser_obj.find_all("a",href=True)
			for link in a_tag_list[1:len(a_tag_list)-1]:
			    #if link['href'].endswith('mp3'):		
				list_.append(link["href"])
				#print link["href"]
				try:			
					os.makedirs("Qaris/"+link["href"])
				except OSError:
					print ""
					#print "folder already exists"
		return list_


def get_next(list_):
	list1_=[]
	flag=False
	count_q=0
	for url in list_: #QARIS
		print "============================================"
		count_q+=1
		next_req = requests.get("https://download.quranicaudio.com/quran/%s" % url,stream =True)
		print ("https://download.quranicaudio.com/quran/%s"%url)
		if next_req.status_code == 200:
			parser_obj2 = BeautifulSoup(next_req.content, "html.parser")
			a_tag_list2=parser_obj2.find_all("a",href=True)
			#print a_tag_list2
			for link2 in a_tag_list2[-26:]: #MP3
					print "-------------------------------------"
					list1_.append(link2["href"])
					href_url=link2["href"]
					#print link2["href"]
					URL2="https://download.quranicaudio.com/quran/"+url+href_url
					#print "URL= ",URL
					mp3_name = URL2.split("/")[-1]
					print "mp3= ",mp3_name
					folder_name=URL2.split("/")[-2]
					print "folder= ",folder_name
					
					#print "FOLDER NAME : ",folder_name	
					if os.path.exists("Qaris/"+folder_name):
						#print "HOOORAHHH"	
						#print mp3_name
						file=open("Qaris/"+folder_name+"/log.txt","a+")
						file.write("%s Total Qari %s \n" % ((datetime.datetime.now().strftime
							   ("%Y-%m-%d %H:%M:%S")),len(list_)))
						file.write("%s Start Processing %s out %s \n" % ((datetime.datetime.now().strftime
							   ("%Y-%m-%d %H:%M:%S")),count_q,len(list_)))
						file.write("%s %s \n" % ((datetime.datetime.now().strftime
							   ("%Y-%m-%d %H:%M:%S")),folder_name))
						file.write("%s %s %s START \n" % ((datetime.datetime.now().strftime
							   ("%Y-%m-%d %H:%M:%S")),folder_name,mp3_name))
						d_audio = requests.get(URL2)
						with open("Qaris/"+folder_name+"/"+mp3_name, 'wb') as writefile:
             					       writefile.write(d_audio.content)
						file.write("%s %s %s END \n" % ((datetime.datetime.now().strftime
							   ("%Y-%m-%d %H:%M:%S")),folder_name,mp3_name))
			
								
			#merging files
			file=open("Qaris/"+folder_name+"/log.txt","a+")			
			file.write("%s Merging the files of %s START \n" % ((datetime.datetime.now().strftime
							  ("%Y-%m-%d %H:%M:%S")),folder_name))
			#os.system('mp3wrap "Qaris/"+folder_name+"/secondhalf.mp3" *.mp3')
			os.system("mp3wrap " + "Qaris/"+folder_name+"/second_Half.mp3 " + "Qaris/"+folder_name+"/"+"*.mp3")
			file.write("%s Merging the files of %s End \n\n" % ((datetime.datetime.now().strftime
							  ("%Y-%m-%d %H:%M:%S")),folder_name))	
	
				



def main():
	URL="https://download.quranicaudio.com/quran/"
	m_list_=get_qaris(URL)
	m_list2_=get_next(m_list_)
	#print m_list_
	#download_images(m_list_,m_list2_)

if __name__=="__main__":
	main()
