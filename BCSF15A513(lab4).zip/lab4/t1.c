//initializing dynamic array + resizing it and then freeing the memory
#include<stdio.h>
#include<stdlib.h>

int main()
{
	//int i=0;
	int j;
	int i;
	int size=10;
     	int * arr = (int*)malloc(sizeof(int)*size);
	
	if(arr==NULL)
	{
		perror("malloc failed\n");
	}

    	for(j=0;j<size;j++)
	{
		arr[j] = j;
		//printf("%d",arr[j]);	
        }

	for(j=0;j<size;j++)
	{
		printf("%d ",arr[j]);
        } 
	printf("\n");
	int newsize=20;
	int *narr=(int*)realloc(arr,sizeof(int)*newsize);
		if(narr==NULL)
			{ perror("realloc failed\n");}
		else
			arr=narr;
		
	for( j=0;j<newsize;j++)
	{
		arr[j]=j;
        }
	for(j=0;j<newsize;j++)
	{
		printf("%d ",arr[j]);
        }
	printf("\n");
	free(arr);
	
	
	return 0;
}
