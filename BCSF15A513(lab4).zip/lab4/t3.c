//using setjmp() and longjmp() to check their behavior.for this purpose i am storing the setjmp value in counter and then using longjmp
//in both functions to make a jump from the current function to main function that cannot be done by using goto,label thing. 
#include <setjmp.h>
#include<stdio.h>
jmp_buf env;
void firstSetJump(int *counter);
void haveFun(int *counter);

int main()
{
int counter=setjmp(env);
//printf("heheheh %d",counter);
//printf("\n");

switch(counter)
{
case 0:
	firstSetJump(&counter);
	break;
case 1:
	haveFun(&counter);
	break;
case 2:
  	printf("COUNTER value in main() after exiting from haveFun() = %d",counter);printf("\n");
	break;
}

return 0;

}


void firstSetJump(int *counter)
{
    printf("COUNTER value in firstSetJump() = %d",*counter);
    printf("\n");
    longjmp(env,++(*counter));
}

void haveFun(int *counter)
{
    printf("COUNTER value in haveFun() = %d",*counter);
    printf("\n");
    
    longjmp(env,++(*counter));
}
