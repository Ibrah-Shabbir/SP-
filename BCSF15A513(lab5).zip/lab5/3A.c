#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int globalvariable = 54; 
int main(){
	
	pid_t cpid;
	//printf("Before fork()\n");
	cpid = fork();
	if (cpid == -1){
		printf("Fork failed\n");
		exit(1);
	}
	if (cpid == 0){
		printf("FORK Successful\n");	
		printf("CHILD = %ld \n",(long)getpid());	
	}
	else
	{
		wait(cpid);
		printf("PARENT = %ld \n",(long)getppid());
		
	}
	

	return 0;
}


//on creating the child process using fork() if it returns -1 then the fork() failed means that the child process creation is unsuccessful 
//if fork() returns 0 it means that child has been created. If the value returned is other than 0 and -1 then its the parent process.
