#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

int main(){
	printf("My Real user-ID is: %ld\n", (long)getuid());
	printf("My Effective user-ID is: %ld\n", (long)geteuid());
	printf("My Real group-ID is: %ld\n", (long)getgid());
	printf("My Effective group-ID is: %ld\n", (long)getegid());


	return 0;
}


//Real userid is the id of the user running the process
//Effective userid is the id of the owner
//Real groupid is the groupid of the user running the process
//Effective groupid is the groupid of the owner
// here in this program the file owner is ibrah having id=1000 and same user is running the process hence EUID=RUID && EGID=RUID  
