#include<stdio.h>
#include<unistd.h>
#include<errno.h>
extern errno;

int main()
{
	uid_t ruid, euid, suid;
	gid_t rgid, egid, sgid;
	getresuid(&ruid, &euid, &suid);
        printf("My Real user-ID is:%ld\n",(long)ruid);
	printf("My Effective user-ID is: %ld\n", (long)euid);
	printf("My Saved Set-user-ID is: %ld\n", (long)suid);
	getresgid(&rgid,&egid,&sgid);
	printf("My Real group-ID is: %ld\n", (long)rgid);
	printf("My Effective group-ID is: %ld\n", (long)egid);
	printf("My Saved Set-group-ID is: %ld\n", (long)sgid);
	//SETTING SETUID
	int set=setuid(501);
	if (set != -1)
	{	
		getresuid(&ruid, &euid, &suid);
		getresgid(&rgid,&egid,&sgid);
		printf("\n\nAfter seteuid(501) the IDs are:\n");
		printf("My Real user-ID is:%ld\n",(long)ruid);
		printf("My Effective user-ID is: %ld\n", (long)euid);
		printf("My Saved Set-user-ID is: %ld\n", (long)suid);
		printf("My Effective group-ID is: %ld\n", (long)egid);
		printf("My Saved Set-group-ID is: %ld\n", (long)sgid);
	}
	else
	{
		printf ("Error in setting EUID\n");
	}

	
	return 0;

}

//When an unprivileged process calls setuid() only the effective user ID of the process is changed. Furthermore, it can be changed only to the same values as either the real user ID or saved set user-ID. 
// When a privileged process calls setuid() with a non zero argument here it is 501 then real, effective & saved set user ID are all set to the value specified in the uid/gid argument.
