//using dynamic link here for creating library.checking the changings in different versions
#include<stdio.h>
#include "myMath.h"
#include "myStr.h"
int main()
{
        int x,y;
	printf("enter the value of x :");
	scanf("%d",&x);
	printf("enter the value of y :");
	scanf("%d",&y);
	int isequal=isEqual(x,y);
	printf("\n");
	Swap(x,y);
	printf("\n");
	return 0;
}
