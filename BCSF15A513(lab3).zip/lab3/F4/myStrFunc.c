#include<stdio.h>
#include "string.h"

int isPalindrome(char* arr , int size)
{
  
  int i,ret=1;
  //while(arr[length]!='\0') length++;
 
for(i=0;i<size;i++)
{ 
	if((arr[0+i]!=arr[(size-1)-i]))
	{
		ret=-1;
		//printf("yes its palindrome \n");
		break;
	}
	
	
}
  return ret;

}
