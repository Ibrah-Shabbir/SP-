#include<stdio.h>
int isEqual(int x,int y)
{
       int value=-1;
  	if(x==y)
	{
		//printf( "equal V2 \n");
		printf( "equal \n");
		value=1;
		return value;
	}
	else
	{	value=-1;
		//printf( "not equal V2\n");
		printf( "not equal \n");
		return value;
	}
	return value;
}


void Swap(int x,int y)
{
	//printf("V2 before swapping x is %d y is %d \n",x,y);
	printf("before swapping x is %d y is %d \n",x,y);
        x=x+y;
	y=x-y;
	x=x-y;
   	//printf("V2 after swapping x is %d y is %d \n",x,y);
	printf("V after swapping x is %d y is %d \n",x,y);	
}


