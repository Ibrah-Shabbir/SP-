int isEqual(int ,int);
int Swap(int,int );
