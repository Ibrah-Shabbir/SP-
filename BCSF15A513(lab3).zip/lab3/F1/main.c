//made a header file in this project and accessing the functions by including the header file 

#include<stdio.h>
#include "myMath.h"
int main()
{
        int x,y;
	printf("enter the value of x :");
	scanf("%d",&x);
	printf("enter the value of y :");
	scanf("%d",&y);
	int isequal=isEqual(x,y);
	printf("\n");
	Swap(x,y);
	printf("\n");
	return 0;
}
