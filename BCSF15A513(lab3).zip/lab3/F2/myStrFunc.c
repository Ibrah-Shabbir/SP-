#include<stdio.h>
#include "string.h"

int isPalindrome(char* arr , int size)
{
  
  int i,value=1;
 
for(i=0;i<size;i++)
{ 
	if((arr[0+i]!=arr[(size-1)-i]))
	{
		value=-1;
		//printf("yes its palindrome \n");
		break;
	}
	
	
}
  return value;

}
