//made a header file in this project and accessing the functions by including the header file using angular brackets
#include<stdio.h>
#include<string.h>
#include<myStr.h>

int main()
{
	char arr[]="aba";
   	//printf("enter the string :");
	if(isPalindrome(arr,3)==1)
	{
	   printf("yes its palindrome \n");
	}
	else
	{
 	   printf("no its not palindrome \n");
	}
	//scanf("%s",&arr);

}
